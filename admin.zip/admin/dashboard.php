<?php
session_start();

// Vérifier si l'utilisateur est connecté et a le rôle 'admin'
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    $_SESSION['error'] = "Accès non autorisé.";
    header("Location: ../index.php");
    exit();
}

// Inclure la configuration de la base de données
try {
    require_once '../config/database.php';
    $pdo = getConnection();
} catch (PDOException $e) {
    die("Erreur : Impossible de se connecter à la base de données : " . $e->getMessage());
}

// Récupérer les statistiques globales (tous les utilisateurs)
try {
    // Total colis
    $sql_colis = "SELECT COUNT(*) as total_colis, COALESCE(SUM(package_fee), 0) as total_package_fee 
                  FROM colis";
    $stmt_colis = $pdo->prepare($sql_colis);
    $stmt_colis->execute();
    $colis_data = $stmt_colis->fetch(PDO::FETCH_ASSOC);
    $total_colis = $colis_data['total_colis'];
    $total_package_fee = $colis_data['total_package_fee'];

    // Total réservations et totaux financiers
    $sql_reservations = "SELECT COUNT(*) as total_reservations, 
                                COALESCE(SUM(r.total_amount), 0) as total_amount,
                                COALESCE(SUM(f.tariff), 0) as total_tariff,
                                COALESCE(SUM(f.tax), 0) as total_tax,
                                COALESCE(SUM(f.port_fee), 0) as total_port_fee
                         FROM reservations r
                         JOIN trips t ON r.trip_id = t.id
                         LEFT JOIN finances f ON r.passenger_type = f.passenger_type 
                         AND (CASE 
                              WHEN t.departure_port = 'ANJ' AND t.arrival_port = 'MWA' THEN 'ANJ-MWA'
                              ELSE 'Standard'
                              END) = f.trip_type";
    $stmt_reservations = $pdo->prepare($sql_reservations);
    $stmt_reservations->execute();
    $reservations_data = $stmt_reservations->fetch(PDO::FETCH_ASSOC);
    $total_reservations = $reservations_data['total_reservations'];
    $total_tariff = $reservations_data['total_tariff'];
    $total_tax = $reservations_data['total_tax'];
    $total_port_fee = $reservations_data['total_port_fee'];
} catch (PDOException $e) {
    die("Erreur lors de la récupération des statistiques : " . $e->getMessage());
}

// Récupérer la date pour le rapport (par défaut : aujourd'hui)
$report_date = isset($_GET['report_date']) ? $_GET['report_date'] : date('Y-m-d');

// Rapport journalier : Réservations du jour
try {
    $sql_daily_reservations = "SELECT r.passenger_name, f.tariff, f.port_fee, f.tax, r.total_amount
                              FROM reservations r
                              JOIN trips t ON r.trip_id = t.id
                              LEFT JOIN finances f ON r.passenger_type = f.passenger_type 
                              AND (CASE 
                                   WHEN t.departure_port = 'ANJ' AND t.arrival_port = 'MWA' THEN 'ANJ-MWA'
                                   ELSE 'Standard'
                                   END) = f.trip_type
                              WHERE r.departure_date = ?";
    $stmt_daily_reservations = $pdo->prepare($sql_daily_reservations);
    $stmt_daily_reservations->execute([$report_date]);
    $daily_reservations = $stmt_daily_reservations->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Erreur lors de la récupération des réservations journalières : " . $e->getMessage());
}

// Rapport journalier : Colis du jour
try {
    $sql_daily_colis = "SELECT sender_name, package_reference, package_fee
                        FROM colis 
                        WHERE DATE(created_at) = ?";
    $stmt_daily_colis = $pdo->prepare($sql_daily_colis);
    $stmt_daily_colis->execute([$report_date]);
    $daily_colis = $stmt_daily_colis->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Erreur lors de la récupération des colis journaliers : " . $e->getMessage());
}

// Totaux journaliers pour le graphique et le résumé
try {
    $sql_daily_totals = "SELECT COALESCE(SUM(f.tariff), 0) as daily_tariff,
                                COALESCE(SUM(f.tax), 0) as daily_tax,
                                COALESCE(SUM(f.port_fee), 0) as daily_port_fee,
                                COALESCE(SUM(r.total_amount), 0) as daily_total
                         FROM reservations r
                         JOIN trips t ON r.trip_id = t.id
                         LEFT JOIN finances f ON r.passenger_type = f.passenger_type 
                         AND (CASE 
                              WHEN t.departure_port = 'ANJ' AND t.arrival_port = 'MWA' THEN 'ANJ-MWA'
                              ELSE 'Standard'
                              END) = f.trip_type
                         WHERE r.departure_date = ?";
    $stmt_daily_totals = $pdo->prepare($sql_daily_totals);
    $stmt_daily_totals->execute([$report_date]);
    $daily_totals = $stmt_daily_totals->fetch(PDO::FETCH_ASSOC);

    $sql_daily_colis_totals = "SELECT COALESCE(SUM(package_fee), 0) as daily_package_fee
                               FROM colis 
                               WHERE DATE(created_at) = ?";
    $stmt_daily_colis_totals = $pdo->prepare($sql_daily_colis_totals);
    $stmt_daily_colis_totals->execute([$report_date]);
    $daily_colis_totals = $stmt_daily_colis_totals->fetch(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Erreur lors de la récupération des totaux journaliers : " . $e->getMessage());
}

$pdo = null;
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tableau de Bord Admin - Adore Comores Express</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="../styles/css/admin_dashboard.css?v=<?php echo time(); ?>">
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.3/dist/chart.umd.min.js"></script>
</head>
<body>
    <!-- Sidebar -->
    <aside class="sidebar">
        <div class="user-profile">
            <i class="fas fa-user-circle"></i>
            <span><?php echo htmlspecialchars($_SESSION['username']); ?></span>
        </div>
        <nav class="nav-menu">
            <a href="dashboard.php" class="active"><i class="fas fa-tachometer-alt"></i><span>Tableau de Bord</span></a>
            <a href="trips.php"><i class="fas fa-ticket-alt"></i><span>Gestion des Trajets</span></a>
            <a href="finances.php"><i class="fas fa-money-bill-wave"></i><span>Finances</span></a>
            <a href="users.php"><i class="fas fa-users"></i><span>Utilisateurs</span></a>
            <a href="seats.php"><i class="fas fa-chair"></i><span>Gestion des Places</span></a>
            <a href="reservations.php"><i class="fas fa-book"></i><span>Réservations</span></a>
            <a href="tickets.php"><i class="fas fa-ticket"></i><span>Gestion des Tickets</span></a>
            <a href="references.php"><i class="fas fa-barcode"></i><span>Références</span></a>
            <a href="info_passagers.php"><i class="fas fa-user-friends"></i><span>Infos Passagers</span></a>
            <a href="../ticket.php"><i class="fas fa-ticket-alt"></i> Tickets</a>
            <a href="../chat.php"><i class="fas fa-comments"></i><span>Chat de Groupe</span></a>

            <a href="../auth/logout.php" class="logout"><i class="fas fa-sign-out-alt"></i><span>Se Déconnecter</span></a>
        </nav>
    </aside>

    <!-- Main Content -->
    <main class="main-content">
        <div class="overlay">
            <h1>Bienvenue, <?php echo htmlspecialchars($_SESSION['username']); ?>!</h1>
            <p>Gérez efficacement les opérations maritimes d'Adore Comores Express avec une interface moderne et sécurisée.</p>
            <div class="dashboard-stats">
                <div class="stat-card">
                    <i class="fas fa-box"></i>
                    <h2><?php echo $total_colis; ?></h2>
                    <p>Colis Enregistrés</p>
                </div>
                <div class="stat-card">
                    <i class="fas fa-book"></i>
                    <h2><?php echo $total_reservations; ?></h2>
                    <p>Réservations Effectuées</p>
                </div>
                <div class="stat-card">
                    <i class="fas fa-money-bill"></i>
                    <h2><?php echo number_format($total_tariff, 2); ?> KMF</h2>
                    <p>Total des Tarifs</p>
                </div>
                <div class="stat-card">
                    <i class="fas fa-percent"></i>
                    <h2><?php echo number_format($total_tax, 2); ?> KMF</h2>
                    <p>Total des Taxes</p>
                </div>
                <div class="stat-card">
                    <i class="fas fa-anchor"></i>
                    <h2><?php echo number_format($total_port_fee, 2); ?> KMF</h2>
                    <p>Total des Frais Portuaires</p>
                </div>
                <div class="stat-card">
                    <i class="fas fa-shipping-fast"></i>
                    <h2><?php echo number_format($total_package_fee, 2); ?> KMF</h2>
                    <p>Total des Frais de Colis</p>
                </div>
            </div>

            <!-- Rapport Journalier -->
            <div class="daily-report">
                <h2>Rapport Journalier - <?php echo date('d/m/Y', strtotime($report_date)); ?></h2>
                <form method="GET" class="date-filter">
                    <label for="report_date">Choisir une date : </label>
                    <input type="date" id="report_date" name="report_date" value="<?php echo $report_date; ?>">
                    <button type="submit">Filtrer</button>
                </form>
                <a href="export_daily_report.php?report_date=<?php echo $report_date; ?>" class="export-btn"><i class="fas fa-file-pdf"></i> Exporter en PDF</a>

                <!-- Résumé des totaux journaliers -->
                <div class="daily-summary">
                    <h3>Totaux Financiers du Jour</h3>
                    <div class="summary-stats">
                        <div class="summary-card">
                            <i class="fas fa-money-bill"></i>
                            <h4><?php echo number_format($daily_totals['daily_tariff'], 2); ?> KMF</h4>
                            <p>Total des Tarifs</p>
                        </div>
                        <div class="summary-card">
                            <i class="fas fa-percent"></i>
                            <h4><?php echo number_format($daily_totals['daily_tax'], 2); ?> KMF</h4>
                            <p>Total des Taxes</p>
                        </div>
                        <div class="summary-card">
                            <i class="fas fa-anchor"></i>
                            <h4><?php echo number_format($daily_totals['daily_port_fee'], 2); ?> KMF</h4>
                            <p>Total des Frais Portuaires</p>
                        </div>
                        <div class="summary-card">
                            <i class="fas fa-book"></i>
                            <h4><?php echo number_format($daily_totals['daily_total'], 2); ?> KMF</h4>
                            <p>Total des Réservations</p>
                        </div>
                        <div class="summary-card">
                            <i class="fas fa-shipping-fast"></i>
                            <h4><?php echo number_format($daily_colis_totals['daily_package_fee'], 2); ?> KMF</h4>
                            <p>Total des Frais de Colis</p>
                        </div>
                    </div>
                </div>

                <!-- Graphique -->
                <div class="chart-container">
                    <canvas id="dailyChart"></canvas>
                </div>

                <h3>Réservations du Jour</h3>
                <?php if (!empty($daily_reservations)): ?>
                    <table>
                        <thead>
                            <tr>
                                <th>Passager</th>
                                <th>Tarif (KMF)</th>
                                <th>Frais Portuaires (KMF)</th>
                                <th>Taxes (KMF)</th>
                                <th>Total (KMF)</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($daily_reservations as $reservation): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($reservation['passenger_name']); ?></td>
                                    <td><?php echo number_format($reservation['tariff'], 2); ?></td>
                                    <td><?php echo number_format($reservation['port_fee'], 2); ?></td>
                                    <td><?php echo number_format($reservation['tax'], 2); ?></td>
                                    <td><?php echo number_format($reservation['total_amount'], 2); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <p>Aucune réservation trouvée pour cette date.</p>
                <?php endif; ?>

                <h3>Colis du Jour</h3>
                <?php if (!empty($daily_colis)): ?>
                    <table>
                        <thead>
                            <tr>
                                <th>Expéditeur</th>
                                <th>Référence</th>
                                <th>Frais de Port (KMF)</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($daily_colis as $colis): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($colis['sender_name']); ?></td>
                                    <td><?php echo htmlspecialchars($colis['package_reference']); ?></td>
                                    <td><?php echo number_format($colis['package_fee'], 2); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <p>Aucun colis trouvé pour cette date.</p>
                <?php endif; ?>
            </div>
        </div>
    </main>
    <script>
        // Données pour le graphique
        const chartData = {
            labels: ['Tarifs', 'Taxes', 'Frais Portuaires', 'Réservations', 'Frais de Colis'],
            datasets: [{
                label: 'Totaux Journaliers (KMF)',
                data: [
                    <?php echo $daily_totals['daily_tariff']; ?>,
                    <?php echo $daily_totals['daily_tax']; ?>,
                    <?php echo $daily_totals['daily_port_fee']; ?>,
                    <?php echo $daily_totals['daily_total']; ?>,
                    <?php echo $daily_colis_totals['daily_package_fee']; ?>
                ],
                backgroundColor: [
                    'rgba(30, 64, 175, 0.6)', // #1e40af
                    'rgba(249, 115, 22, 0.6)', // #f97316
                    'rgba(75, 192, 192, 0.6)',
                    'rgba(255, 206, 86, 0.6)',
                    'rgba(153, 102, 255, 0.6)'
                ],
                borderColor: [
                    'rgba(30, 64, 175, 1)',
                    'rgba(249, 115, 22, 1)',
                    'rgba(75, 192, 192, 1)',
                    'rgba(255, 206, 86, 1)',
                    'rgba(153, 102, 255, 1)'
                ],
                borderWidth: 1
            }]
        };
    </script>
    <script src="../styles/js/admin_dashboard.js?v=<?php echo time(); ?>"></script>
</body>
</html>