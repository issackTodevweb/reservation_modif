<?php
session_start();

// Vérifier si l'utilisateur est connecté et a le rôle 'admin'
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    $_SESSION['error'] = "Accès non autorisé.";
    header("Location: ../index.php");
    exit();
}

// Inclure la configuration de la base de données
try {
    require_once '../config/database.php';
    $pdo = getConnection();
} catch (PDOException $e) {
    die("Erreur : Impossible de se connecter à la base de données : " . $e->getMessage());
}

// Paramètres de tri et filtre
$filter_date = isset($_GET['filter_date']) ? $_GET['filter_date'] : date('Y-m-d');
$sort_column = isset($_GET['sort']) ? $_GET['sort'] : 'departure_date';
$sort_order = isset($_GET['order']) && $_GET['order'] === 'asc' ? 'ASC' : 'DESC';
$allowed_columns = ['passenger_name', 'phone_number', 'nationality', 'with_baby', 'departure_date', 'reference_number'];
$sort_column = in_array($sort_column, $allowed_columns) ? $sort_column : 'departure_date';

// Construire la requête SQL
$sql = "SELECT r.passenger_name, r.phone_number, r.nationality, r.with_baby, 
               t.departure_port, t.arrival_port, r.departure_date, t.departure_time, 
               ref.reference_number
        FROM reservations r
        JOIN trips t ON r.trip_id = t.id
        JOIN reference ref ON r.reference_id = ref.id
        WHERE r.departure_date = :filter_date
        ORDER BY $sort_column $sort_order";
try {
    $stmt = $pdo->prepare($sql);
    $stmt->execute(['filter_date' => $filter_date]);
    $passengers = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Erreur lors de la récupération des données des passagers : " . $e->getMessage());
}

$pdo = null;
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Informations des Passagers - Adore Comores Express</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="../styles/css/admin_info_passagers.css?v=<?php echo time(); ?>">
</head>
<body>
    <!-- Sidebar -->
    <aside class="sidebar">
        <div class="user-profile">
            <i class="fas fa-user-circle"></i>
            <span><?php echo htmlspecialchars($_SESSION['username']); ?></span>
        </div>
        <nav class="nav-menu">
            <a href="dashboard.php"><i class="fas fa-tachometer-alt"></i><span>Tableau de Bord</span></a>
            <a href="trips.php"><i class="fas fa-ticket-alt"></i><span>Gestion des Trajets</span></a>
            <a href="finances.php"><i class="fas fa-money-bill-wave"></i><span>Finances</span></a>
            <a href="users.php"><i class="fas fa-users"></i><span>Utilisateurs</span></a>
            <a href="seats.php"><i class="fas fa-chair"></i><span>Gestion des Places</span></a>
            <a href="reservations.php"><i class="fas fa-book"></i><span>Réservations</span></a>
            <a href="tickets.php"><i class="fas fa-ticket"></i><span>Gestion des Tickets</span></a>
            <a href="references.php"><i class="fas fa-barcode"></i><span>Références</span></a>
            <a href="info_passagers.php" class="active"><i class="fas fa-user-friends"></i><span>Infos Passagers</span></a>
            <a href="../ticket.php"><i class="fas fa-ticket-alt"></i> Tickets</a>
            <a href="../chat.php"><i class="fas fa-comments"></i><span>Chat de Groupe</span></a>
            <a href="../auth/logout.php" class="logout"><i class="fas fa-sign-out-alt"></i><span>Se Déconnecter</span></a>
        </nav>
    </aside>

    <!-- Main Content -->
    <main class="main-content">
        <div class="overlay">
            <h1>Informations des Passagers</h1>
            <p>Consultez et triez les informations des passagers pour tous les trajets.</p>

            <!-- Filtre par date -->
            <div class="filter-section">
                <form method="GET" class="date-filter">
                    <label for="filter_date">Filtrer par date de départ :</label>
                    <input type="date" id="filter_date" name="filter_date" value="<?php echo htmlspecialchars($filter_date); ?>">
                    <button type="submit">Filtrer</button>
                </form>
                <a href="export_passagers.php?filter_date=<?php echo htmlspecialchars($filter_date); ?>" class="export-btn"><i class="fas fa-file-pdf"></i> Exporter en PDF</a>
            </div>

            <!-- Tableau des passagers -->
            <div class="passenger-list">
                <h2>Liste des Passagers - <?php echo date('d/m/Y', strtotime($filter_date)); ?></h2>
                <?php if (!empty($passengers)): ?>
                    <table>
                        <thead>
                            <tr>
                                <?php
                                $columns = [
                                    'passenger_name' => 'Nom du Passager',
                                    'phone_number' => 'Téléphone',
                                    'nationality' => 'Nationalité',
                                    'with_baby' => 'Avec Bébé',
                                    'departure_date' => 'Trajet',
                                    'reference_number' => 'Référence'
                                ];
                                foreach ($columns as $col => $label) {
                                    $new_order = ($sort_column === $col && $sort_order === 'ASC') ? 'desc' : 'asc';
                                    echo "<th><a href='?filter_date=$filter_date&sort=$col&order=$new_order'>$label " . ($sort_column === $col ? ($sort_order === 'ASC' ? '↑' : '↓') : '') . "</a></th>";
                                }
                                ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($passengers as $passenger): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($passenger['passenger_name']); ?></td>
                                    <td><?php echo htmlspecialchars($passenger['phone_number']); ?></td>
                                    <td><?php echo htmlspecialchars($passenger['nationality']); ?></td>
                                    <td><?php echo htmlspecialchars($passenger['with_baby']); ?></td>
                                    <td><?php echo htmlspecialchars($passenger['departure_port'] . ' → ' . $passenger['arrival_port'] . ', ' . date('d/m/Y H:i', strtotime($passenger['departure_date'] . ' ' . $passenger['departure_time']))); ?></td>
                                    <td><?php echo htmlspecialchars($passenger['reference_number']); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <p>Aucun passager trouvé pour cette date.</p>
                <?php endif; ?>
            </div>
        </div>
    </main>
    <script src="../styles/js/admin_info_passagers.js?v=<?php echo time(); ?>"></script>
</body>
</html>