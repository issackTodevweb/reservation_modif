<?php
session_start();

// Vérifier si l'utilisateur est connecté et a le rôle admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    $_SESSION['error'] = "Accès non autorisé.";
    header("Location: ../index.php");
    exit();
}

// Inclure la configuration de la base de données
try {
    require_once '../config/database.php';
    $conn = getConnection();
} catch (PDOException $e) {
    die("Erreur : Impossible de se connecter à la base de données. Vérifiez config/database.php : " . $e->getMessage());
}

// Gestion de la recherche
$search_query = isset($_GET['search']) ? trim($_GET['search']) : '';
$where_clause = '';
$params = [];
if (!empty($search_query)) {
    $where_clause = " WHERE r.passenger_name LIKE ? OR r.departure_date LIKE ? OR ref.reference_number LIKE ? OR tck.ticket_number LIKE ? OR r.nationality LIKE ? OR r.user_id LIKE ?";
    $search_param = '%' . $search_query . '%';
    $params = [$search_param, $search_param, $search_param, $search_param, $search_param, $search_param];
}

// Récupérer la liste des réservations
try {
    $sql = "SELECT r.id, r.passenger_name, r.phone_number, r.nationality, r.passenger_type, r.with_baby, tck.ticket_type, 
                   r.departure_date, t.departure_port, t.arrival_port, ref.reference_number, tck.ticket_number, 
                   r.seat_number AS selected_seat, r.payment_status, f.tariff, f.tax, f.port_fee, r.total_amount AS total, 
                   u.username AS cashier_name, r.user_id, r.trip_id, r.reference_id, r.ticket_id
            FROM reservations r
            LEFT JOIN trips t ON r.trip_id = t.id
            LEFT JOIN users u ON r.user_id = u.id
            LEFT JOIN reference ref ON r.reference_id = ref.id
            LEFT JOIN tickets tck ON r.ticket_id = tck.id
            LEFT JOIN finances f ON r.passenger_type = f.passenger_type 
                AND (t.type = 'aller' AND f.trip_type = 'Standard' OR t.type = 'aller-retour' AND f.trip_type = 'ANJ-MWA')
            $where_clause
            ORDER BY r.created_at DESC";
    $stmt = $conn->prepare($sql);
    $stmt->execute($params);
    $reservations = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Erreur lors de la récupération des réservations : " . $e->getMessage());
}

// Récupérer les trajets pour la modale
try {
    $stmt = $conn->query("SELECT id, departure_port, arrival_port, departure_date, type FROM trips ORDER BY departure_date");
    $trips = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Erreur lors de la récupération des trajets : " . $e->getMessage());
}

// Récupérer les places disponibles pour chaque trajet
try {
    $stmt = $conn->query("SELECT s.id, s.trip_id, s.seat_number, s.status, t.departure_date 
                          FROM seats s 
                          JOIN trips t ON s.trip_id = t.id 
                          WHERE s.status = 'free' 
                          ORDER BY t.departure_date, s.seat_number");
    $seats = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Erreur lors de la récupération des places : " . $e->getMessage());
}

// Récupérer les utilisateurs pour afficher le nom du caissier dans la modale
try {
    $stmt = $conn->query("SELECT id, username FROM users WHERE role = 'cashier' ORDER BY username");
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Erreur lors de la récupération des utilisateurs : " . $e->getMessage());
}

// Ajouter ou mettre à jour une réservation
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_reservation'])) {
    $id = (int)$_POST['id'];
    $passenger_name = trim($_POST['passenger_name']);
    $phone_number = trim($_POST['phone_number']);
    $nationality = trim($_POST['nationality']);
    $passenger_type = $_POST['passenger_type'];
    $with_baby = $_POST['with_baby'];
    $departure_date = $_POST['departure_date'];
    $trip_id = (int)$_POST['trip_id'];
    $seat_number = $_POST['seat_number'];
    $payment_status = $_POST['payment_status'];

    // Récupérer l'user_id existant de la réservation (non modifiable)
    try {
        $stmt = $conn->prepare("SELECT user_id FROM reservations WHERE id = ?");
        $stmt->execute([$id]);
        $reservation = $stmt->fetch(PDO::FETCH_ASSOC);
        $user_id = $reservation['user_id'];
    } catch (PDOException $e) {
        $_SESSION['error'] = "Erreur lors de la récupération de l'ID caissier : " . $e->getMessage();
        header("Location: reservations.php" . (!empty($search_query) ? "?search=" . urlencode($search_query) : ""));
        exit();
    }

    // Récupérer tariff, tax, port_fee depuis finances
    try {
        $stmt = $conn->prepare("SELECT tariff, tax, port_fee 
                               FROM finances 
                               WHERE passenger_type = ? AND trip_type = (SELECT CASE 
                                   WHEN type = 'aller' THEN 'Standard' 
                                   ELSE 'ANJ-MWA' 
                               END FROM trips WHERE id = ?)");
        $stmt->execute([$passenger_type, $trip_id]);
        $finance = $stmt->fetch(PDO::FETCH_ASSOC);
        $total_amount = $finance ? ($finance['tariff'] + $finance['tax'] + $finance['port_fee']) : 0;
    } catch (PDOException $e) {
        $_SESSION['error'] = "Erreur lors de la récupération des finances : " . $e->getMessage();
        header("Location: reservations.php" . (!empty($search_query) ? "?search=" . urlencode($search_query) : ""));
        exit();
    }

    // Vérifier la disponibilité du siège
    try {
        $stmt = $conn->prepare("SELECT status FROM seats WHERE trip_id = ? AND seat_number = ? AND status = 'free'");
        $stmt->execute([$trip_id, $seat_number]);
        $seat = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$seat && $seat_number !== $reservations[array_search($id, array_column($reservations, 'id'))]['selected_seat']) {
            $_SESSION['error'] = "Le siège sélectionné n'est pas disponible.";
            header("Location: reservations.php" . (!empty($search_query) ? "?search=" . urlencode($search_query) : ""));
            exit();
        }
    } catch (PDOException $e) {
        $_SESSION['error'] = "Erreur lors de la vérification du siège : " . $e->getMessage();
        header("Location: reservations.php" . (!empty($search_query) ? "?search=" . urlencode($search_query) : ""));
        exit();
    }

    // Mettre à jour la réservation
    try {
        $stmt = $conn->prepare("UPDATE reservations SET passenger_name = ?, phone_number = ?, nationality = ?, 
                               passenger_type = ?, with_baby = ?, departure_date = ?, trip_id = ?, seat_number = ?, 
                               payment_status = ?, total_amount = ?, user_id = ? WHERE id = ?");
        $stmt->execute([$passenger_name, $phone_number, $nationality, $passenger_type, $with_baby, $departure_date, 
                        $trip_id, $seat_number, $payment_status, $total_amount, $user_id, $id]);

        // Mettre à jour le siège
        $stmt = $conn->prepare("UPDATE seats SET status = 'occupied' WHERE trip_id = ? AND seat_number = ?");
        $stmt->execute([$trip_id, $seat_number]);
        $_SESSION['success'] = "Réservation mise à jour avec succès.";
    } catch (PDOException $e) {
        $_SESSION['error'] = "Erreur lors de la mise à jour : " . $e->getMessage();
    }
    header("Location: reservations.php" . (!empty($search_query) ? "?search=" . urlencode($search_query) : ""));
    exit();
}

// Supprimer une réservation
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_reservation'])) {
    $id = (int)$_POST['delete_reservation'];
    try {
        $stmt = $conn->prepare("SELECT trip_id, seat_number FROM reservations WHERE id = ?");
        $stmt->execute([$id]);
        $reservation = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($reservation) {
            $stmt = $conn->prepare("DELETE FROM reservations WHERE id = ?");
            $stmt->execute([$id]);

            $stmt = $conn->prepare("UPDATE seats SET status = 'free' WHERE trip_id = ? AND seat_number = ?");
            $stmt->execute([$reservation['trip_id'], $reservation['seat_number']]);
            $_SESSION['success'] = "Réservation supprimée avec succès.";
        }
    } catch (PDOException $e) {
        $_SESSION['error'] = "Erreur lors de la suppression : " . $e->getMessage();
    }
    header("Location: reservations.php" . (!empty($search_query) ? "?search=" . urlencode($search_query) : ""));
    exit();
}

// Annuler une réservation
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['cancel_reservation'])) {
    $id = (int)$_POST['cancel_reservation'];
    try {
        $stmt = $conn->prepare("SELECT trip_id, seat_number FROM reservations WHERE id = ?");
        $stmt->execute([$id]);
        $reservation = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($reservation) {
            $stmt = $conn->prepare("UPDATE reservations SET payment_status = 'Annulé' WHERE id = ?");
            $stmt->execute([$id]);

            $stmt = $conn->prepare("UPDATE seats SET status = 'free' WHERE trip_id = ? AND seat_number = ?");
            $stmt->execute([$reservation['trip_id'], $reservation['seat_number']]);
            $_SESSION['success'] = "Réservation annulée avec succès.";
        }
    } catch (PDOException $e) {
        $_SESSION['error'] = "Erreur lors de l'annulation : " . $e->getMessage();
    }
    header("Location: reservations.php" . (!empty($search_query) ? "?search=" . urlencode($search_query) : ""));
    exit();
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion des Réservations - Adore Comores Express</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="../styles/css/admin_reservations.css?v=<?php echo time(); ?>">
</head>
<body>
    <!-- Sidebar -->
    <aside class="sidebar">
        <div class="user-profile">
            <i class="fas fa-user-circle"></i>
            <span><?php echo htmlspecialchars($_SESSION['username']); ?></span>
        </div>
        <nav class="nav-menu">
            <a href="dashboard.php"><i class="fas fa-tachometer-alt"></i> Tableau de Bord</a>
            <a href="trips.php"><i class="fas fa-ticket-alt"></i> Gestion des Trajets</a>
            <a href="finances.php"><i class="fas fa-money-bill-wave"></i> Finances</a>
            <a href="users.php"><i class="fas fa-users"></i> Utilisateurs</a>
            <a href="seats.php"><i class="fas fa-chair"></i> Gestion des Places</a>
            <a href="reservations.php" class="active"><i class="fas fa-book"></i> Réservations</a>
            <a href="tickets.php"><i class="fas fa-ticket"></i>Gestion des Tickets</a>
            <a href="references.php"><i class="fas fa-barcode"></i> Références</a>
            <a href="info_passagers.php"><i class="fas fa-user-friends"></i><span>Infos Passagers</span></a>
            <a href="../ticket.php"><i class="fas fa-ticket-alt"></i> Tickets</a>
            <a href="../chat.php"><i class="fas fa-comments"></i><span>Chat de Groupe</span></a>
            <a href="../auth/logout.php" class="logout"><i class="fas fa-sign-out-alt"></i> Se Déconnecter</a>
        </nav>
    </aside>

    <!-- Main Content -->
    <main class="main-content">
        <div class="overlay">
            <h1>Gestion des Réservations</h1>
            <?php if (isset($_SESSION['success'])): ?>
                <div class="alert alert-success"><?php echo htmlspecialchars($_SESSION['success']); ?></div>
                <?php unset($_SESSION['success']); ?>
            <?php endif; ?>
            <?php if (isset($_SESSION['error'])): ?>
                <div class="alert alert-error"><?php echo htmlspecialchars($_SESSION['error']); ?></div>
                <?php unset($_SESSION['error']); ?>
            <?php endif; ?>
            <div class="reservations-container">
                <h2>Liste des Réservations</h2>
                <!-- Barre de recherche -->
                <div class="search-container">
                    <form method="GET" action="reservations.php">
                        <input type="text" name="search" placeholder="Rechercher par nom, date, référence, ticket, ID caissier..." value="<?php echo htmlspecialchars($search_query); ?>">
                        <button type="submit" class="btn"><i class="fas fa-search"></i> Rechercher</button>
                        <?php if (!empty($search_query)): ?>
                            <a href="reservations.php" class="btn reset-btn">Réinitialiser</a>
                        <?php endif; ?>
                    </form>
                </div>
                <?php if (!empty($reservations)): ?>
                    <table>
                        <thead>
                            <tr>
                                <th>ID de l'utilisateur</th>
                                <th>Nom du Passager</th>
                                <th>Téléphone</th>
                                <th>Nationalité</th>
                                <th>Type de Passager</th>
                                <th>Avec Bébé</th>
                                <th>Type de Ticket</th>
                                <th>Date de Départ</th>
                                <th>Trajet</th>
                                <th>Référence</th>
                                <th>Numéro de Ticket</th>
                                <th>Place</th>
                                <th>Statut de Paiement</th>
                                <th>Tarif (KMF)</th>
                                <th>Taxe (KMF)</th>
                                <th>Frais Port (KMF)</th>
                                <th>Total (KMF)</th>
                                <th>Caissier</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($reservations as $reservation): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($reservation['user_id']); ?></td>
                                    <td><?php echo htmlspecialchars($reservation['passenger_name']); ?></td>
                                    <td><?php echo htmlspecialchars($reservation['phone_number']); ?></td>
                                    <td><?php echo htmlspecialchars($reservation['nationality']); ?></td>
                                    <td><?php echo htmlspecialchars($reservation['passenger_type']); ?></td>
                                    <td><?php echo htmlspecialchars($reservation['with_baby']); ?></td>
                                    <td><?php echo htmlspecialchars($reservation['ticket_type']); ?></td>
                                    <td><?php echo htmlspecialchars($reservation['departure_date']); ?></td>
                                    <td><?php echo htmlspecialchars($reservation['departure_port'] . ' → ' . $reservation['arrival_port']); ?></td>
                                    <td><?php echo htmlspecialchars($reservation['reference_number']); ?></td>
                                    <td><?php echo htmlspecialchars($reservation['ticket_number']); ?></td>
                                    <td><?php echo htmlspecialchars($reservation['selected_seat']); ?></td>
                                    <td><?php echo htmlspecialchars($reservation['payment_status']); ?></td>
                                    <td><?php echo htmlspecialchars(number_format($reservation['tariff'] ?? 0, 2)); ?></td>
                                    <td><?php echo htmlspecialchars(number_format($reservation['tax'] ?? 0, 2)); ?></td>
                                    <td><?php echo htmlspecialchars(number_format($reservation['port_fee'] ?? 0, 2)); ?></td>
                                    <td><?php echo htmlspecialchars(number_format($reservation['total'], 2)); ?></td>
                                    <td><?php echo htmlspecialchars($reservation['cashier_name']); ?></td>
                                    <td>
                                        <button class="btn edit-btn" 
                                                data-id="<?php echo $reservation['id']; ?>" 
                                                data-passenger-name="<?php echo htmlspecialchars($reservation['passenger_name']); ?>" 
                                                data-phone-number="<?php echo htmlspecialchars($reservation['phone_number']); ?>" 
                                                data-nationality="<?php echo htmlspecialchars($reservation['nationality']); ?>" 
                                                data-passenger-type="<?php echo htmlspecialchars($reservation['passenger_type']); ?>" 
                                                data-with-baby="<?php echo htmlspecialchars($reservation['with_baby']); ?>" 
                                                data-departure-date="<?php echo htmlspecialchars($reservation['departure_date']); ?>" 
                                                data-trip-id="<?php echo $reservation['trip_id']; ?>" 
                                                data-seat-number="<?php echo htmlspecialchars($reservation['selected_seat']); ?>" 
                                                data-payment-status="<?php echo htmlspecialchars($reservation['payment_status']); ?>" 
                                                data-user-id="<?php echo $reservation['user_id']; ?>" 
                                                data-cashier-name="<?php echo htmlspecialchars($reservation['cashier_name']); ?>">Modifier</button>
                                        <form method="POST" style="display: inline;" onsubmit="return confirm('Voulez-vous vraiment supprimer cette réservation ?');">
                                            <input type="hidden" name="delete_reservation" value="<?php echo $reservation['id']; ?>">
                                            <button type="submit" class="btn delete-btn">Supprimer</button>
                                        </form>
                                        <?php if ($reservation['payment_status'] !== 'Annulé'): ?>
                                            <form method="POST" style="display: inline;" onsubmit="return confirm('Voulez-vous vraiment annuler cette réservation ?');">
                                                <input type="hidden" name="cancel_reservation" value="<?php echo $reservation['id']; ?>">
                                                <button type="submit" class="btn cancel-btn">Annuler</button>
                                            </form>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <p>Aucune réservation trouvée.</p>
                <?php endif; ?>
            </div>

            <!-- Modale pour modification -->
            <div id="editReservationModal" class="modal">
                <div class="modal-content">
                    <span class="modal-close">&times;</span>
                    <h2>Modifier la réservation</h2>
                    <form id="editReservationForm" method="POST">
                        <input type="hidden" name="update_reservation" value="1">
                        <input type="hidden" name="id" id="edit_id">
                        <div class="form-group">
                            <label for="edit_passenger_name">Nom du Passager</label>
                            <input type="text" name="passenger_name" id="edit_passenger_name" required>
                        </div>
                        <div class="form-group">
                            <label for="edit_phone_number">Téléphone</label>
                            <input type="text" name="phone_number" id="edit_phone_number" required>
                        </div>
                        <div class="form-group">
                            <label for="edit_nationality">Nationalité</label>
                            <input type="text" name="nationality" id="edit_nationality" required>
                        </div>
                        <div class="form-group">
                            <label for="edit_passenger_type">Type de Passager</label>
                            <select name="passenger_type" id="edit_passenger_type" required>
                                <option value="Comorien Adulte">Comorien Adulte</option>
                                <option value="Comorien Enfant">Comorien Enfant</option>
                                <option value="Étranger Adulte">Étranger Adulte</option>
                                <option value="Étranger Enfant">Étranger Enfant</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="edit_with_baby">Avec Bébé</label>
                            <select name="with_baby" id="edit_with_baby" required>
                                <option value="Oui">Oui</option>
                                <option value="Non">Non</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="edit_departure_date">Date de Départ</label>
                            <input type="date" name="departure_date" id="edit_departure_date" required>
                        </div>
                        <div class="form-group">
                            <label for="edit_trip_id">Trajet</label>
                            <select name="trip_id" id="edit_trip_id" required>
                                <?php foreach ($trips as $trip): ?>
                                    <option value="<?php echo $trip['id']; ?>">
                                        <?php echo htmlspecialchars($trip['departure_port'] . ' → ' . $trip['arrival_port'] . ' (' . $trip['departure_date'] . ')'); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="edit_seat_number">Place</label>
                            <select name="seat_number" id="edit_seat_number" required>
                                <?php foreach ($seats as $seat): ?>
                                    <option value="<?php echo htmlspecialchars($seat['seat_number']); ?>" 
                                            data-trip-id="<?php echo $seat['trip_id']; ?>">
                                        <?php echo htmlspecialchars($seat['seat_number'] . ' (' . $seat['departure_date'] . ')'); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="edit_payment_status">Statut de Paiement</label>
                            <select name="payment_status" id="edit_payment_status" required>
                                <option value="Mvola">Mvola</option>
                                <option value="Espèce">Espèce</option>
                                <option value="Non payé">Non payé</option>
                                <option value="Annulé">Annulé</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="edit_user_id">ID d'utilisateur</label>
                            <input type="text" id="edit_user_id" readonly>
                            <input type="hidden" name="user_id" id="edit_user_id_hidden">
                        </div>
                        <button type="submit" class="btn update-btn">Mettre à jour</button>
                    </form>
                </div>
            </div>
        </div>
    </main>

    <script src="../styles/js/admin_reservations.js?v=<?php echo time(); ?>"></script>
</body>
</html>
<?php $conn = null; ?>